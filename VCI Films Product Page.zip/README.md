
  # VCI Films Product Page

  This is a code bundle for VCI Films Product Page. The original project is available at https://www.figma.com/design/ZCdjUayfZZEvqx64QZL3mX/VCI-Films-Product-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  